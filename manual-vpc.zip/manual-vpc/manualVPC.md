# Manual VPC

## 1. Creación de la VPC

El primer paso será crear nuestra propia VPC, a partir de la cual asignaremos las demás configuraciones.

Para ello:
1. Accede al apartado de **VPC** en AWS.
2. Haz clic en **Crear VPC**.
3. Asigna un nombre a la VPC.
4. Configura el bloque IPv4 según tu necesidad. En este manual, usaremos el valor predeterminado.

Adjunto las capturas para mayor claridad:

![Creación de VPC](./1.png)
![Creación de VPC](./2.png)
![Creación de VPC](./3.png)

## 2. Creación de Subredes

El siguiente paso es crear las subredes. Es importante asignarlas manualmente, ya que, si no lo hacemos, se asignarán por defecto y no podremos configurarlas con los valores deseados.

Pasos:
1. Ve a **Subredes** dentro de la VPC.
2. Crea una nueva subred y asigna un rango de direcciones dentro del bloque CIDR de la VPC.
3. Repite este proceso para cada subred necesaria.

Capturas de la configuración:

![Creación de Subredes](./4.png)
![Creación de Subredes](./5.png)
![Creación de Subredes](./6.png)

## 3. Creación de la Puerta de Enlace de Internet

Para que la VPC tenga acceso a Internet, debemos crear una **Internet Gateway** y asociarla a la VPC.

Pasos:
1. Accede a **Puertas de enlace de Internet**.
2. Crea una nueva **Internet Gateway**.
3. Asígnala a la VPC correspondiente.

Capturas del proceso:

![Creación de Gateway](./8.png)
![Creación de Gateway](./9.png)

## 4. Configuración de Tablas de Enrutamiento

Ahora debemos configurar las **Tablas de Enrutamiento** para permitir la conexión a Internet.

Pasos:
1. Accede a **Tablas de Enrutamiento**.
2. Crea una nueva tabla y asóciala a la VPC.
3. Añade una ruta para permitir el tráfico de salida hacia la **Internet Gateway**.
4. Asigna la tabla de enrutamiento a las subredes públicas.

Capturas del proceso:

![Creación de Tabla de Enrutamiento](./10.png)
![Creación de Tabla de Enrutamiento](./11.png)
![Creación de Tabla de Enrutamiento](./12.png)
![Configuración de Subredes](./subredes1.png)

## 5. Lanzamiento de una Instancia

Finalmente, lanzaremos una instancia dentro de la VPC que hemos creado.

Pasos:
1. Accede al apartado de **EC2** en AWS.
2. Crea una nueva instancia.
3. Selecciona la VPC y la subred correspondiente.
4. Configura los demás parámetros según tus necesidades.

Capturas del proceso:

![Crear Instancia](./13.png)
![Crear Instancia](./14.png)
![Crear Instancia](./15.png)
![Crear Instancia](./16.png)
![Crear Instancia](./17.png)
![Crear Instancia](./18.png)

Una vez completados estos pasos, solo queda conectar la instancia y actualizar la consola.